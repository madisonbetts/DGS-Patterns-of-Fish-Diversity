setwd("~/Swainia/Meristics")

# Performs principal component analysis, Mahalanobis distance calculations, and LDA on meristic trait data 
# Accompanies Stokes et al., 2025 (Evolution)


library(tidyverse)
library(readxl)
library(factoextra)
library(MASS)
library(ggplot2)
library(GenAlgo)
library(caret)

bt = read_excel('Meristics_P_brucethompsoni.xlsx')
stf = read_excel('Meristics_P_nasuta_st_Francis.xlsx')
arkphox = read_excel('Meristics_P_phoxocephala_Arkansas.xlsx'); 
arknas = read_excel('Meristics_P_nasuta_Arkansas.xlsx'); arknas = transform(arknas, AbLL = as.numeric(AbLL))
whitenas = read_excel('Meristics_P_nasuta_White.xlsx')
nasuta = read_excel('Meristics_P_nasuta_LilRed.xlsx');  
redphox = read_excel('Meristics_P_phoxocephala_Red.xlsx')
blackphox = read_excel('Meristics_P_phoxocephala_Black.xlsx')
phox = read_excel('Meristics_P_phoxocephala.xlsx')
  
varlist = c("Trans","D1","D2","A2","P1","CD","AbLL","LL")

bt = bt[,varlist]; bt$response = "bt"
stf = stf[,varlist]; stf$response= "sanfran"
arkphox = arkphox[,varlist]; arkphox$response = "arkphox"
arknas = arknas[,varlist]; arknas$response= "arknas"
whitenas = whitenas[,varlist]; whitenas$response = "whitenas"
nasuta = nasuta[,varlist]; nasuta$response = "nasuta"
redphox = redphox[,varlist]; redphox$response = "redphox"
blackphox = blackphox[,varlist]; blackphox$response = "blackphox"
phox = phox[,varlist]; phox$response = "phox"

alldata = bind_rows(bt,stf, arkphox,arknas, whitenas, nasuta, redphox, blackphox,phox)
alldata = na.omit(alldata)
response = alldata$response
alldata = subset(alldata,select=-c(response))

data.pca <- prcomp(alldata,scale.=FALSE)
summary(data.pca)


fviz_eig(data.pca, addlabels = TRUE)
fviz_pca_var(data.pca, axes = c(1,2),col.var = "black")
fviz_cos2(data.pca, choice = "var", axes = 2)
fviz_pca_ind(data.pca,label="none",habillage=response, addEllipses=TRUE, ellipse.level=0.95)

ix = as.character(which(response== "bt" | response == "redphox"))
fviz_pca_ind(data.pca, label = "none",habillage=response,addEllipses = TRUE, ellipse.level = 0.95, ellipse.type = "norm",select.ind = list(name=ix))
ix = as.character(which(response== "arknas" | response == "arkphox"))
fviz_pca_ind(data.pca, label = "none",habillage=response,addEllipses = TRUE, ellipse.level = 0.95, ellipse.type = "norm",select.ind = list(name=ix))
ix = as.character(which(response== "blackphox" | response == "sanfran"))
fviz_pca_ind(data.pca, label = "none",habillage=response,addEllipses = TRUE, ellipse.level = 0.95, ellipse.type = "norm",select.ind = list(name=ix))
ix = as.character(which(response== "nasuta" | response == "whitenas"))
fviz_pca_ind(data.pca, label = "none",habillage=response,addEllipses = TRUE, ellipse.level = 0.95, ellipse.type = "norm",select.ind = list(name=ix))

t = get_pca_ind(data.pca) 
tt = data.frame(t$coord)

# MAHALANOBIS CALCULATION 
ix = response== "bt" | response == "redphox"
M1 = maha(tt[ix,],response[ix],method="mve")

ix = response== "arknas" | response == "arkphox"
M2 = maha(tt[ix,],response[ix],method="mve")

ix = response== "blackphox" | response == "sanfran"
M3 = maha(tt[ix,],response[ix],method="mve")

ix = response== "nasuta" | response == "whitenas"
M4 = maha(tt[ix,],response[ix],method="mve")

# LDA WITH K-FOLD CROSS VALIDATION
set.seed("123")
ctrl <- trainControl(method = "cv", number = 10,savePredictions="final") 
lda_cv <- train(response ~ ., data = cbind(response,alldata), method = "lda", trControl = ctrl) #prior reflects sample size
conf_mat = confusionMatrix(lda_cv$pred$pred,lda_cv$pred$obs)

new_order <- c("nasuta","whitenas","arknas","arkphox","bt","redphox","sanfran","blackphox","phox")
reordered_table <- conf_mat$table[new_order, new_order]
print(reordered_table)

