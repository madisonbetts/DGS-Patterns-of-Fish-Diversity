# Script to accompany Stokes et al., 2025 --> principal component analysis of abiotic variables
# The data has been queried and pre-processed in the script 'getStreamCatData.R'
# Use the file "ENM_Data.csv" to reproduce the analytical steps

df_use = read.csv("ENM_Data.csv") #data has been compiled from the National Hydrography Dataset, the EPA StreamCat Database, and the State Geologic Map Compilation
response <- df_use$NameCode
COMID <- df_use $COMID 

df_use = subset(df_use,select=-c(NameCode,COMID))

library(ggplot2)
library(ggcorrplot)
library(FactoMineR)
library(corrr)
library(factoextra)

data_normalized = scale(df_use)
corr_matrix <- cor(data_normalized)

ggcorrplot(corr_matrix) # this was used to check colinearity and remove variables (data shown here has already been pre-processed)

data.pca <- prcomp(df_use,scale.=TRUE)
summary(data.pca)
fviz_eig(data.pca, addlabels = TRUE)
fviz_pca_var(data.pca, axes = c(1,2),col.var = "black")
fviz_cos2(data.pca, choice = "var", axes = 1)

## Plot individual observations 
ix = rownames(df_use[(response== "arknasuta" | response == "arkphox"),])
fviz_pca_ind(data.pca, label = "none",habillage=response,addEllipses = TRUE, ellipse.level = 0.95, ellipse.type = "norm",select.ind = list(name=ix))
ix = rownames(df_use[(response== "redphox" | response == "brucethompsoni"),])
fviz_pca_ind(data.pca, label = "none",habillage=response,addEllipses = TRUE, ellipse.level = 0.95, ellipse.type = "norm",select.ind = list(name=ix))
ix = rownames(df_use[(response== "blackphox" | response == "frsnasuta"),])
fviz_pca_ind(data.pca, label = "none",habillage=response,addEllipses = TRUE, ellipse.level = 0.95, ellipse.type = "norm",select.ind = list(name=ix))
ix = rownames(df_use[(response== "nasuta_LR" | response == "nasuta"),])
fviz_pca_ind(data.pca, label = "none",habillage=response,addEllipses = TRUE, ellipse.level = 0.95, ellipse.type = "norm",select.ind = list(name=ix))

#compare the difference in presence points between sister species
a = get_pca_ind(data.pca) 
tt = data.frame(a$coord)
tt$response = response

lab1 = "arknasuta"
lab2 = "arkphox"
pvals = matrix(,nrow=4,ncol=8)
meandif = matrix(,nrow=4,ncol=8)
for (i in 1:8){
  aa = t.test(tt[tt$response==lab1,i], tt[tt$response==lab2,i], alternative = "two.sided", var.equal = FALSE)
  pvals[1,i] = aa$p.value
  meandif[1,i] = aa$estimate[1]-aa$estimate[2]
}

lab1 = "brucethompsoni"
lab2 = "redphox"
for (i in 1:8){
  aa = t.test(tt[tt$response==lab1,i], tt[tt$response==lab2,i], alternative = "two.sided", var.equal = FALSE)
  pvals[2,i] = aa$p.value
  meandif[2,i] = aa$estimate[1]-aa$estimate[2]}

lab1 = "nasuta_LR"
lab2 = "nasuta"
for (i in 1:8){
  aa = t.test(tt[tt$response==lab1,i], tt[tt$response==lab2,i], alternative = "two.sided", var.equal = FALSE)
  pvals[3,i] = aa$p.value
  meandif[3,i] = aa$estimate[1]-aa$estimate[2]}

lab1 = "frsnasuta"
lab2 = "blackphox"
for (i in 1:8){
  aa = t.test(tt[tt$response==lab1,i], tt[tt$response==lab2,i], alternative = "two.sided", var.equal = FALSE)
  pvals[4,i] = aa$p.value
  meandif[4,i] = aa$estimate[1]-aa$estimate[2]}

pvals2 = p.adjust(pvals,method="holm")


# to compare to the background environment, use a bootstrapping approach to estimate the 95% CI mean of background 

#install.packages("simpleboot")
library(simpleboot)


niter = 10000

lab1 = "absence_arknasuta"
lab2 = "absence_arkphox"
ci_difs1 = matrix(,nrow=4,ncol=8)
ci_difs2 = matrix(,nrow=4,ncol=8)
SE = matrix(,nrow=4,ncol=8)
BMEAN = matrix(,nrow=4,ncol=8)

for (i in 1:8){
  x = tt[tt$response==lab1,i]
  y = tt[tt$response==lab2,i]
  bootstrapped <- two.boot(x, y, mean, niter)
  bootstrapped_mean_diff <- data.frame(bootstrapped$t)
  colnames(bootstrapped_mean_diff) <- 'mean_diffs'
  SE[1,i] = sd(bootstrapped_mean_diff$mean_diffs)/sqrt(niter)
  BMEAN[1,i] = mean(bootstrapped_mean_diff$mean_diffs)
  ci_difs1[1,i] <- quantile(bootstrapped_mean_diff$mean_diffs, 0.05)
  ci_difs2[1,i] =  quantile(bootstrapped_mean_diff$mean_diffs, 0.95)
}

lab1 = "absence_brucethompsoni"
lab2 = "absence_redphox"
ci_difs = data.frame()
for (i in 1:8){
  x = tt[tt$response==lab1,i]
  y = tt[tt$response==lab2,i]
  bootstrapped <- two.boot(x, y, mean, niter)
  
  bootstrapped_mean_diff <- data.frame(bootstrapped$t)
  colnames(bootstrapped_mean_diff) <- 'mean_diffs'
  ci_difs1[2,i] <- quantile(bootstrapped_mean_diff$mean_diffs, 0.05)
  ci_difs2[2,i] =  quantile(bootstrapped_mean_diff$mean_diffs, 0.95)
  
  SE[2,i] = sd(bootstrapped_mean_diff$mean_diffs)/sqrt(niter)
  BMEAN[2,i] = mean(bootstrapped_mean_diff$mean_diffs)
}


lab1 = "absence_nasuta_LR"
lab2 = "absence_nasuta"
ci_difs = data.frame()
for (i in 1:8){
  x = tt[tt$response==lab1,i]
  y = tt[tt$response==lab2,i]
  bootstrapped <- two.boot(x, y, mean, niter)
  
  bootstrapped_mean_diff <- data.frame(bootstrapped$t)
  
  colnames(bootstrapped_mean_diff) <- 'mean_diffs'
  ci_difs1[3,i] <- quantile(bootstrapped_mean_diff$mean_diffs, 0.05)
  ci_difs2[3,i] =  quantile(bootstrapped_mean_diff$mean_diffs, 0.95)
  
  SE[3,i] = sd(bootstrapped_mean_diff$mean_diffs)/sqrt(niter)
  BMEAN[3,i] = mean(bootstrapped_mean_diff$mean_diffs)
}

lab1 = "absence_frsnasuta"
lab2 = "absence_blackphox"
ci_difs = data.frame()
for (i in 1:8){
  x = tt[tt$response==lab1,i]
  y = tt[tt$response==lab2,i]
  bootstrapped <- two.boot(x, y, mean, niter)
  
  bootstrapped_mean_diff <- data.frame(bootstrapped$t)
  colnames(bootstrapped_mean_diff) <- 'mean_diffs'
  ci_difs1[4,i] <- quantile(bootstrapped_mean_diff$mean_diffs, 0.05)
  ci_difs2[4,i] =  quantile(bootstrapped_mean_diff$mean_diffs, 0.95)
  
  SE[4,i] = sd(bootstrapped_mean_diff$mean_diffs)/sqrt(niter)
  BMEAN[4,i] = mean(bootstrapped_mean_diff$mean_diffs)
}

rownames(meandif) = c("PphoArk/PphoNas","Pbru/PphoRed","PnasWhite/Pnas","PnasFr/PphoBlack")
colnames(meandif) = c("PC1","PC2","PC3","PC4","PC5","PC6","PC7","PC8")
meandif = data.frame(meandif)

rownames(ci_difs1) = c("PphoArk/PphoNas","Pbru/PphoRed","PnasWhite/Pnas","PnasFr/PphoBlack")
colnames(ci_difs1) = c("PC1","PC2","PC3","PC4","PC5","PC6","PC7","PC8")
ci_difs1 = data.frame(ci_difs1)

rownames(ci_difs2) = c("PphoArk/PphoNas","Pbru/PphoRed","PnasWhite/Pnas","PnasFr/PphoBlack")
colnames(ci_difs2) = c("PC1","PC2","PC3","PC4","PC5","PC6","PC7","PC8")
ci_difs2 = data.frame(ci_difs2)

pvals_adjusted = data.frame(matrix(NA,nrow=4,ncol=8))
colnames(pvals_adjusted) =c("PC1","PC2","PC3","PC4","PC5","PC6","PC7","PC8")
rownames(pvals_adjusted)=c("PphoArk/PphoNas","Pbru/PphoRed","PnasWhite/Pnas","PnasFr/PphoBlack")
pvals_adjusted[] = pvals2

#write_csv(meandif,"PCA_AVERAGE.csv")
#write_csv(ci_difs1,"BACKGROUND1.csv")
#write_csv(ci_difs2,"BACKGROUND2.csv")
#write_csv(pvals_adjusted,"pvals_adjusted.csv")
  
## Plot the absolute value of the difference in means between presence points and the 95% CI of difference between background envs 

meandif = as.matrix(meandif)
ci_difs1 = as.matrix(ci_difs1)
ci_difs2 = as.matrix(ci_difs2)

x = c(1:8)
x = rev(x)
ggplot()+
  geom_point(aes(x=abs(meandif[4,]),y=x),size=4,color="black")+
  geom_errorbar(aes(xmin=abs(ci_difs1[4,]),xmax=abs(ci_difs2[4,]),y=x),width=0.4)+
  labs(title="PphoBlack + PnasStFr") +
  coord_cartesian(xlim = c(min(abs(c(ci_difs1[4,],ci_difs2[4,])))-0.1,max(abs(c(ci_difs1[4,],ci_difs2[4,]))))+0.1)


ggplot()+
  geom_point(aes(x=abs(meandif[3,]),y=x),size=4,color="black")+
  geom_errorbar(aes(xmin=abs(ci_difs1[3,]),xmax=abs(ci_difs2[3,]),y=x),width=0.4)+
  labs(title="PnasLR + PnasWhite")+
  coord_cartesian(xlim = c(min(abs(c(ci_difs1[3,],ci_difs2[3,])))-0.1,max(abs(c(ci_difs1[3,],ci_difs2[3,]))))+0.1)
  
ggplot()+
  geom_point(aes(x=abs(meandif[2,]),y=x),size=4,color="black")+
  geom_errorbar(aes(xmin=abs(ci_difs1[2,]),xmax=abs(ci_difs2[2,]),y=x),width=0.4)+
  labs(title="PphoRed + Pbru")+
  coord_cartesian(xlim = c(min(abs(c(ci_difs1[2,],ci_difs2[2,])))-0.1,1.4))

ggplot()+
  geom_point(aes(x=abs(meandif[1,]),y=x),size=4,color="black")+
  geom_errorbar(aes(xmin=abs(ci_difs1[1,]),xmax=abs(ci_difs2[1,]),y=x),width=0.4)+
  labs(title="PnasArk + PphoArk")+ 
  coord_cartesian(xlim = c(min(abs(c(ci_difs1[1,],ci_difs2[1,]))),max(abs(meandif[1,]))))

