# Script to download and clean data passed from ArcGIS Pro and query the EPA StreamCat database
# locality data is first clipped to the National Hydrography Dataset V2 dataset
# each locality is assigned a COMID from ArcGIS Pro and associated data (slope, discharge, velocity)

# this script accompanies Stokes et al., 2025 Evolution 


#install.packages('remotes')
library(remotes)
#install_github("USEPA/StreamCatTools", build_vignettes=FALSE, force=TRUE)
library('StreamCatTools')
#vignette("StreamCatTools")
#install.packages('readxl')
library("readxl") 
#install.packages('tidyverse')
library(tidyverse)

#The CSVs read here have been snapped to NHD Flowlines in ArcGIS Pro 
presence = read.csv('SwainiaNHDFlowline.csv') # read presence data
presence2 = read.csv('ddRADstudyspeciesNHD.csv') #additional presence data 
presence2 = presence2[!is.na(presence2$COMID),]

presence = subset(presence,select = c(COMID,TotDASqKM,MAXELEVSMO,MINELEVSMO,SLOPE,QE_MA,VE_MA,NameCode))
presence2 = subset(presence2,select = c(COMID,TotDASqKM,MAXELEVSMO,MINELEVSMO,SLOPE,QE_MA,VE_MA,NameCode))
colnames(presence2) = colnames(presence)
presence_combined = rbind(presence,presence2)


a = duplicated(presence_combined$COMID) # remove any duplicate comid's 
all_presence = presence_combined[!a,]

#these are the categories to keep within NHDPlus 
varsdf = read.csv("StreamCatVariableList2.csv") # read variable names for streamcat
varnames = varsdf$Name1[varsdf$UseMe==1] #variables to use specified in spreadsheet

#absence data - produced in ArcGIS Pro (sampled across the drainage basins where each species lives using a spatially uniform random sampling)
#30% of background NHD flowlines are included for each species' range
all_absence = read.csv("randombackground30percent.csv")
all_absence = subset(all_absence,select=c(NHDFlowline_August2024_COMID,namecode,NHDFlowline_August2024_TotDASqKM,NHDFlowline_August2024_MAXELEVSMO,NHDFlowline_August2024_MINELEVSMO,NHDFlowline_August2024_SLOPE,NHDFlowline_August2024_QE_MA,NHDFlowline_August2024_VE_MA))
a = duplicated(all_absence$NHDFlowline_August2024_COMID) # remove any duplicate comid's 
all_absence = all_absence[!a,]

presencelab = unique(all_presence$NameCode)
absencelab = unique(all_absence$namecode)

colnames(all_absence) = c("COMID","NameCode","TotDASqKM_1","MAXELEVSMO_1","MINELEVSMO_1","SLOPE_1","QE_MA","VE_MA")

all_data = rbind(all_absence,all_presence)

#Rock-type data acquired from the State Geologic Map Compilation (SGMC)
#The % of each rock-type at the catchment scale is calculated and lumped as follows
rocktype = read.csv("rockstats3.csv")
rockdf = data.frame(matrix(0,nrow=nrow(all_data),ncol=13))
colnames(rockdf) = c('COMID','Clastic','Clastic Fine','Shale','Limestone','Coarse-detrital','Medium-detrital','Dolostone','Igneous','Rhyolite','Fine-detrital','Chert','Chalk')
rocknames = c('Clastic','Clastic Fine','Shale','Limestone','Coarse-detrital','Medium-detrital','Dolostone','Igneous','Rhyolite','Fine-detrital','Chert','Chalk')
for (i in 1:nrow(all_data)) {
  ix = rocktype$FEATUREID %in% all_data$COMID[i] 
  rocklist = rocktype[ix,]
  rockdf$COMID[i] = all_data$COMID[i]
  for (j in 1:12) {
    ixi = rocklist$MAJOR1 %in% rocknames[j]
    if (sum(ixi)>0){
      rockdf[i,j+1] = rocklist$PERCENTAGE[ixi]
    }
  }
}


all_data = merge(rockdf,all_data)
scdata = data.frame()

## Query STREAMCAT database in chunks; connection will time-out if you try and do it all at once
for (x in seq(from=200,to=22082,by=200)){
  scdata1 = sc_get_data(metric=paste(varnames,collapse = ","), aoi='cat', comid=all_data$COMID[(x-200+1):x])
  scdata = rbind(scdata,scdata1)
}
scdata1 = sc_get_data(metric=paste(varnames,collapse = ","), aoi='cat', comid=all_data$COMID[22001:22082])
scdata = rbind(scdata,scdata1)

## Query STREAMCAT NLCD database in chunks; connection will time-out if you try and do it all at once
sc_nlcd_data = data.frame()
for (x in seq(from=200,to=22082,by=200)){
  sc_nlcd1 = sc_nlcd(year='2019', aoi='cat',comid=all_data$COMID[(x-200+1):x])
  sc_nlcd_data = rbind(sc_nlcd_data,sc_nlcd1)
}

sc_nlcd1 = sc_nlcd(year='2019', aoi='cat',comid=all_data$COMID[22001:22082])
sc_nlcd_data = rbind(sc_nlcd_data,sc_nlcd1)


names(sc_nlcd_data) <- base::toupper(names(sc_nlcd_data))
names(scdata) <- base::toupper(names(scdata))

all_data = merge(all_data,scdata,all=TRUE)
all_data = merge(all_data,sc_nlcd_data,all=TRUE)

# the following steps merge land-cover categories, log-transform topographic and hydrologic data, finds average elevation, removes infinite/NAN values from the dataset
#sum all urb and ag landcover
all_data$urbtot = all_data$PCTURBOP2019CAT+all_data$PCTURBLO2019CAT+all_data$PCTURBMD2019CAT+all_data$PCTURBHI2019CAT
all_data$agtot = all_data$PCTCROP2019CAT+all_data$PCTHAY2019CAT
all_data$forest = all_data$PCTCONIF2019CAT+all_data$PCTMXFST2019CAT+all_data$PCTDECID2019CAT + all_data$PCTWDWET2019CAT
all_data$noforest = all_data$PCTSHRB2019CAT+all_data$PCTGRS2019CAT +all_data$PCTBL2019CAT + all_data$PCTHBWET2019CAT
all_data$Clastic = all_data$Clastic + all_data$"Clastic Fine"
all_data$Carbonate = all_data$Limestone + all_data$Dolostone
all_data$Detrital = all_data$"Fine-detrital"+all_data$"Medium-detrital"+all_data$"Coarse-detrital"
all_data$Igneous = all_data$Igneous +all_data$Rhyolite
df_use = all_data

df_use$TotDASqKM = log10(df_use$TotDASqKM_1)
df_use$SLOPE = log10(df_use$SLOPE_1)
df_use$QE_MA = log10(df_use$QE_MA)
df_use$VE_MA = log10(df_use$VE_MA)
df_use$MeanELEV = (df_use$MAXELEVSMO_1 + df_use$MINELEVSMO_1)/2

df_use = subset(df_use,select=-c(CLAYCAT,PCTSHRB2019CAT,PCTGRS2019CAT,PCTBL2019CAT,PCTICE2019CAT,PCTBL2019CAT,PCTCONIF2019CAT,PCTMXFST2019CAT,PCTDECID2019CAT,PCTHBWET2019CAT,PCTWDWET2019CAT,PCTOW2019CAT,PCTURBOP2019CAT,PCTURBLO2019CAT,PCTURBMD2019CAT,PCTURBHI2019CAT,PCTCROP2019CAT,PCTHAY2019CAT,MAXELEVSMO_1,MINELEVSMO_1,PCTNONCARBRESIDCAT,PCTCARBRESIDCAT,PCTEOLFINECAT,PCTCOLLUVSEDCAT))
df_use = na.omit(df_use)
df_use = df_use[!is.infinite(df_use$QE_MA),]
df_use = subset(df_use,select=-c(Rhyolite,`Clastic Fine`, `Fine-detrital`,`Medium-detrital`,`Coarse-detrital`, Chalk, Limestone, VE_MA,Dolostone, noforest,urbtot,agtot,TMIN8110CAT,TotDASqKM,TotDASqKM_1,TMEAN8110CAT,RUNOFFCAT,SLOPE_1))

# data was removed for colinearity and if there insufficient points with data for that category (e.g. Rhyolite)
