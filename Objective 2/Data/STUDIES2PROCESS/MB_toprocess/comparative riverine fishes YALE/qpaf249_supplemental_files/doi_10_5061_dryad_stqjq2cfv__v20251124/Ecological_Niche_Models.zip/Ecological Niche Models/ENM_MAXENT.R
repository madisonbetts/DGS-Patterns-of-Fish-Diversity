# Script accompanies Stokes et al., 2025, Evolution 
# The data has been queried and pre-processed in the script 'getStreamCatData.R'
# Use the file "ENM_Data.csv" to reproduce the analytical steps
# This script runs MaxEnt using the 'dismo' R package

df_use <- read.csv("ENM_Data.csv")


response = df_use$NameCode
df_use = subset(df_use,select=-c(NameCode,COMID))


#maxent ENM modeling 
library(dismo)
library(SDMtune)
library(zeallot)
#remotes::install_github("adamlilith/enmSdm")
library(enmSdm)

#code to test maxnet versus maxent

niter <- 100 

pres1 = c("arkphox","blackphox","nasuta_LR","redphox")
pres2 = c("arknasuta","frsnasuta","nasuta","brucethompsoni")
D1_null = matrix(nrow=niter,ncol=4)
D2_null = matrix(nrow=niter,ncol=4)
Dx = vector()

for (i in 1:4){
  
  dfpres1 = df_use[response==pres1[i],] #presence species 1
  dfpres2 = df_use[response==pres2[i],] #presence species 2
  
  abs1 = paste("absence_",pres1[i],sep="") #absence code species 1
  abs2 = paste("absence_",pres2[i],sep="") #absence code species 2
               
  dfabs = df_use[response==abs1 | response == abs2,] #all absence data frame
               
  p <- rep(1,nrow(dfpres1)) #response variable
  a <- rep(0,nrow(dfabs))
  p1 = c(p,a)
  
  dt= rbind(dfpres1,dfabs) # put together presence and absence
  
  # max ent species 1
  mod1_mx = maxent(p=p1,x=dt,args=c('linear=true','product=true','quadratic=true','threshold=false','hinge=false','addsamplestobackground=true'))
 
  p <- rep(1,nrow(dfpres2)) #response species 2
  p1 = c(p,a)
  
  dt= rbind(dfpres2,dfabs) # all data
  
  # max ent species 2
  mod2_mx = maxent(p=p1,x=dt,args=c('linear=true','product=true','quadratic=true','threshold=false','hinge=false','addsamplestobackground=true'))
  
  df_predict_mx = predict(mod1_mx,dfabs) #prediction for species 1 in range of species 1 and 2
  df_predict2_mx = predict(mod2_mx,dfabs) #prediction for species 2 in range of species and 2
  
  df_predict_mx = df_predict_mx/sum(df_predict_mx) #normalized
  df_predict2_mx = df_predict2_mx/sum(df_predict2_mx)
  
  Dx[i] = 1-0.5*sum(abs(df_predict_mx-df_predict2_mx)) #Schoener's D between the two models
  
  ix1 = response == abs1 # which ones are absence species 1
  ixvec = which(ix1)
  
  ix2 = response == abs2 #which ones are absence species 2
  ixvec2 = which(ix2)

  for (j in 1:niter){
    ix2use= sample(ixvec,nrow(dfpres1),replace=FALSE) #randomly sample from ixvec 
    dfrand1 = df_use[ix2use,] #use me as random trainer
    
    p <- rep(1,nrow(dfrand1)) #response
    p1 = c(p,a)
    
    dt= rbind(dfrand1,dfabs)
    
    # model trained on null samples from species 1 range
    mod1_null_mx = maxent(p=p1,x=dt,args=c('linear=true','product=true','quadratic=true','threshold=false','hinge=false','addsamplestobackground=true'))
    
    
    ix2use2= sample(ixvec2,nrow(dfpres2),replace=FALSE) #randomly sample
    dfrand2 = df_use[ix2use2,]
    
    p <- rep(1,nrow(dfrand2))
    p1 = c(p,a)
    dt= rbind(dfrand2,dfabs)
    
    mod2_null_mx = maxent(p=p1,x=dt,args=c('linear=true','product=true','quadratic=true','threshold=false','hinge=false','addsamplestobackground=true'))
    
    df_null_predict = predict(mod1_null_mx,dfabs,clamp=F) # now predict
    df_null_predict2 = predict(mod2_null_mx,dfabs,clamp=F)
    
    df_null_predict = df_null_predict/sum(df_null_predict) #normalize
    df_null_predict2 = df_null_predict2/sum(df_null_predict2)
    
    
    D1_null[j,i] = 1-0.5*sum(abs(df_predict_mx-df_null_predict2)) #schoener's d (pres1 to pres2 rand)
    D2_null[j,i] = 1-0.5*sum(abs(df_predict2_mx-df_null_predict)) #schoener's d (pres2 to pres1 rand)
    
  }
}

library(ggplot2)
for (i in 1:4){

# Create a ggplot object
p <- ggplot() +
  geom_histogram(aes(x = D1_null[1:niter,i], fill = "data1"), alpha = 0.5,binwidth=0.01) +
  geom_histogram(aes(x = D2_null[1:niter,i], fill = "data2"), alpha = 0.5,binwidth=0.01) +
  scale_fill_manual(values = c("data1" = "red", "data2" = "green")) +
  geom_vline(aes(xintercept=Dx[i]),color="blue", linetype="dashed", size=1)+
  labs(title = pres1[i], x = "Value", y = "Frequency")

plot(p)
}
