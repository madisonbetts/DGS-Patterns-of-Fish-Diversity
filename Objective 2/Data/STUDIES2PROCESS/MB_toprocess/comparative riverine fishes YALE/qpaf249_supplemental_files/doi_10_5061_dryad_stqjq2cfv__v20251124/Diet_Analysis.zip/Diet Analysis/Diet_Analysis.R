# This analysis accompanies Stokes et al., 2025 Evolution 
# Here gut content data is analyzed, the results are visualized with bar plots, an NMDS is plotted comparing sister species; and we do a PERMANOVA 
# testing the effect of species and date of collection on gut-contents 

library(vegan)
library(ggplot2)
library(ggrepel)
library(cowplot)
library(dplyr)
#Read in the raw data

library(stringr)

#fix up the data
diet = read.csv("Percina_swainia_total_diet2.csv")
diet = subset(diet,diet$DATE != "na")
date = diet$DATE
response = diet$code
diet2 = diet
diet2 = subset(diet2,select=-c(Lot.ID.number,Species,Location.descrition,Stomach.label.number,N..full.vs.empty.,Standard.Length,notes))
diet2$odan = diet$ODONATA+ diet$Aeshnidae +diet$Coenagrionidae+diet$Lestidae
diet2$Plec = diet$PLECOPTERA+diet$Perlidae
diet2$Eph = diet$EPHEMEROPTERA+diet$Potamanthidae+diet$Heptageniidae+diet$Baetidae+diet$Palingeniidae
diet2$Tri = diet$TRICHOPTERA+diet$Hydropsychidae+diet$Leptoceridae+diet$Hydroptilidae
diet2$Sim = diet$Simuliidae
diet2$Chir = diet$Chironomidae
diet2$Dip = diet$Dip_Pupae
diet2$Fish = diet$FISH.EGGS
diet2$Cera = diet$Ceratopogonidae

diet2 = subset(diet2,select=c(odan,Plec,Eph,Tri,Sim,Chir,Dip,Fish,Cera))
ix = rowSums(diet2)>0
diet2 = diet2[ix,]
response = response[ix]
date = date[ix]
mydata = diet2

PnasArk = mydata[grepl("PnasArk", response), ]
PphoArk = mydata[grepl("PphoArk",response),]
sums <- matrix(data=NA,nrow=2,ncol=9)
sums[1,] <- colSums(PnasArk != 0, na.rm = TRUE)
sums[2,] <-colSums(PphoArk != 0, na.rm = TRUE)
relative_freq <- sums / sum(sums)

# Bar plot
barplot(relative_freq,beside=TRUE,
        col=c("skyblue","tomato"),
        ylab = "Relative Frequency",
        names.arg = colnames(mydata),
        legend.text = c("Pnasark","PphoArk"),
        ylim = c(0, max(relative_freq) + 0.1))

Pbru= mydata[grepl("Pbru", response), ]
PphoRed = mydata[grepl("PphoRed",response),]
sums <- matrix(data=NA,nrow=2,ncol=9)
sums[1,] <- colSums(Pbru != 0, na.rm = TRUE)
sums[2,] <-colSums(PphoRed != 0, na.rm = TRUE)
relative_freq <- sums / sum(sums)

# Bar plot
barplot(relative_freq,beside=TRUE,
        col=c("skyblue","tomato"),
        ylab = "Relative Frequency",
        legend.text = c("Pbru","PphoRed"),
        names.arg = colnames(mydata),
        ylim = c(0, max(relative_freq) + 0.1))

PnasStFr = mydata[grepl("PnasStFr", response), ]
PphoBlack = mydata[grepl("PphoBlack",response),]
sums <- matrix(data=NA,nrow=2,ncol=9)
sums[1,] <- colSums(PnasStFr != 0, na.rm = TRUE)
sums[2,] <-colSums(PphoBlack != 0, na.rm = TRUE)
relative_freq <- sums / sum(sums)

# Bar plot
barplot(relative_freq,beside=TRUE,
        col=c("skyblue","tomato"),
        ylab = "Relative Frequency",
        legend.text = c("PnasStFr","PphoBlack"),
        names.arg = colnames(mydata),
        ylim = c(0, max(relative_freq) + 0.1))

Pnas = mydata[grepl("Pnas", response), ]
PnasWhite = mydata[grepl("PnasWhite",response),]
sums <- matrix(data=NA,nrow=2,ncol=9)
sums[1,] <- colSums(Pnas != 0, na.rm = TRUE)
sums[2,] <-colSums(PnasWhite != 0, na.rm = TRUE)
relative_freq <- sums / sum(sums)

# Bar plot
barplot(relative_freq,beside=TRUE,
        col=c("skyblue","tomato"),
        ylab = "Relative Frequency",
        legend.text = c("Pnas","PnasWhite"),
        names.arg = colnames(mydata),
        ylim = c(0, max(relative_freq) + 0.1))


#perform NMDS with 2 dimensions

mydata_mds2<-metaMDS(mydata, k=2, trymax=400, autotransform=FALSE)

plot(mydata_mds2, type="t", display=c("sites"))
ordiplot(mydata_mds2, type="n")
orditorp(mydata_mds2, display="species", col="dodgerblue2", air=0.01)
orditorp(mydata_mds2, display="sites", col="black", cex=0.4, air=0.01)

swainia_fish_mds2<-mydata_mds2$points
swainia_fish = data.frame(swainia_fish_mds2)
swainia_insects_mds2<-mydata_mds2$species
swainia_insects<-data.frame(swainia_insects_mds2)

plot0<-ggplot(swainia_insects, aes(x=MDS1, y=MDS2))+
	theme_bw()+
	theme(panel.grid.major=element_blank(), panel.grid.minor=element_blank())+
	theme(panel.border=element_rect(size=1.25))+
	geom_point(shape=19, color="dodgerblue4", alpha=0.75, size=3.0)+
#moves point labels away from points, avoids overlapping
	geom_text_repel(aes(MDS1,MDS2, label=rownames(swainia_insects)), fontface='bold', size=3)+
#control axis labels, and the theme controls the font size, etc.
	xlab("MDS axis 1")+
	ylab("MDS axis 2")+
	theme(axis.title.x=element_text(color="black", size=14, face="bold"), 
		axis.title.y=element_text(color="black", size=14, face="bold"),
		axis.text.x=element_text(face="bold", color="black", size=9),
		axis.text.y=element_text(face="bold", color="black", size=9))

plot0 

darter_ecospace1 = swainia_fish[response=="PphoRed" | response=="Pbru",]
darter_ecospace1$clade = response[response=="PphoRed" | response=="Pbru"]
plot1<-ggplot(darter_ecospace1, aes(x=MDS1, y=MDS2, color=clade))+
	theme_bw()+
	theme(panel.grid.major=element_blank(), panel.grid.minor=element_blank())+
	xlab("MDS axis 1")+
	ylab("MDS axis 2")+
	theme(panel.border=element_rect(size=1.25))+
	theme(axis.title.x=element_text(color="black", size=14, face="bold"), 
		axis.title.y=element_text(color="black", size=14, face="bold"),
		axis.text.x=element_text(face="bold", color="black", size=9),
		axis.text.y=element_text(face="bold", color="black", size=9))+
#add a list of colors (in the order that the clades are in), for the points called in the first line by "clade"
	scale_color_manual(name="Clade", values=c("black", "dodgerblue2"))+
#specifies the points
	geom_point(size=1.5, alpha=0.75)+
	geom_jitter(width=0.095, height=0.095)+
#adds an ellipse for each clade
	stat_ellipse(linetype=2, alpha=0.85)
	

plot1 
# Calculate group means (centroids)
centroids <- aggregate(. ~ clade, data = darter_ecospace1, FUN = mean)

# Drop the group column and compute Euclidean distance
vec1 <- as.numeric(centroids[1, -1])
vec2 <- as.numeric(centroids[2, -1])

euclidean_dist <- numeric(0)
# Euclidean distance
euclidean_dist[1] <- sqrt(sum((vec1 - vec2)^2))



darter_ecospace2 = swainia_fish[response=="PnasArk" | response=="PphoArk",]
darter_ecospace2$clade = response[response=="PnasArk" | response=="PphoArk"]
plot2<-ggplot(darter_ecospace2, aes(x=MDS1, y=MDS2, color=clade))+
	theme_bw()+
	theme(panel.grid.major=element_blank(), panel.grid.minor=element_blank())+
	xlab("MDS axis 1")+
	ylab("MDS axis 2")+
	theme(panel.border=element_rect(size=1.25))+
	theme(axis.title.x=element_text(color="black", size=14, face="bold"), 
		axis.title.y=element_text(color="black", size=14, face="bold"),
		axis.text.x=element_text(face="bold", color="black", size=9),
		axis.text.y=element_text(face="bold", color="black", size=9))+
#add a list of colors (in the order that the clades are in), for the points called in the first line by "clade"
	scale_color_manual(name="Clade", values=c("mediumorchid1", "forestgreen"))+
#specifies the points
	geom_point(size=1.5, alpha=0.75)+
	geom_jitter(width=0.095, height=0.095)+
#adds an ellipse for each clade
	stat_ellipse(linetype=2, alpha=0.85)

plot2 

# Calculate group means (centroids)
centroids <- aggregate(. ~ clade, data = darter_ecospace2, FUN = mean)

# Drop the group column and compute Euclidean distance
vec1 <- as.numeric(centroids[1, -1])
vec2 <- as.numeric(centroids[2, -1])

# Euclidean distance
euclidean_dist[2] <- sqrt(sum((vec1 - vec2)^2))




darter_ecospace3 = swainia_fish[response=="PphoBlack" | response=="PnasStFr",]
darter_ecospace3$clade = response[response=="PphoBlack" | response=="PnasStFr"]
plot3<-ggplot(darter_ecospace3, aes(x=MDS1, y=MDS2, color=clade))+
	theme_bw()+
	theme(panel.grid.major=element_blank(), panel.grid.minor=element_blank())+
	xlab("MDS axis 1")+
	ylab("MDS axis 2")+
	theme(panel.border=element_rect(size=1.25))+
	theme(axis.title.x=element_text(color="black", size=14, face="bold"), 
		axis.title.y=element_text(color="black", size=14, face="bold"),
		axis.text.x=element_text(face="bold", color="black", size=9),
		axis.text.y=element_text(face="bold", color="black", size=9))+
#add a list of colors (in the order that the clades are in), for the points called in the first line by "clade"
	scale_color_manual(name="Clade", values=c("darkorange", "firebrick2", "aquamarine3"))+
#specifies the points
	geom_point(size=1.5, alpha=0.75)+
	geom_jitter(width=0.095, height=0.095)+
#adds an ellipse for each clade
	stat_ellipse(linetype=2, alpha=0.85)
	
plot3 

# Calculate group means (centroids)
centroids <- aggregate(. ~ clade, data = darter_ecospace3, FUN = mean)

# Drop the group column and compute Euclidean distance
vec1 <- as.numeric(centroids[1, -1])
vec2 <- as.numeric(centroids[2, -1])

# Euclidean distance
euclidean_dist[3] <- sqrt(sum((vec1 - vec2)^2))



darter_ecospace4 = swainia_fish[response=="Pnas" | response=="PnasWhite",]
darter_ecospace4$clade = response[response=="Pnas" | response=="PnasWhite"]
plot4<-ggplot(darter_ecospace4, aes(x=MDS1, y=MDS2, color=clade))+
  theme_bw()+
  theme(panel.grid.major=element_blank(), panel.grid.minor=element_blank())+
  xlab("MDS axis 1")+
  ylab("MDS axis 2")+
  theme(panel.border=element_rect(size=1.25))+
  theme(axis.title.x=element_text(color="black", size=14, face="bold"), 
        axis.title.y=element_text(color="black", size=14, face="bold"),
        axis.text.x=element_text(face="bold", color="black", size=9),
        axis.text.y=element_text(face="bold", color="black", size=9))+
  #add a list of colors (in the order that the clades are in), for the points called in the first line by "clade"
  scale_color_manual(name="Clade", values=c("darkorange", "firebrick2", "aquamarine3"))+
  #specifies the points
  geom_point(size=1.5, alpha=0.75)+
  geom_jitter(width=0.095, height=0.095)+
  #adds an ellipse for each clade
  stat_ellipse(linetype=2, alpha=0.85)
test = dist(darter_ecospace4[,1:2])

# Calculate group means (centroids)
centroids <- aggregate(. ~ clade, data = darter_ecospace4, FUN = mean)

# Drop the group column and compute Euclidean distance
vec1 <- as.numeric(centroids[1, -1])
vec2 <- as.numeric(centroids[2, -1])

# Euclidean distance
euclidean_dist[4] <- sqrt(sum((vec1 - vec2)^2))


#PERMANOVA 


# include date and species as dependent variables 
mydata$response=response
season = date
season[date %in% c("12","01","02")] = "W"
season[date %in% c("03","04","05")] = "SP"
season[date %in% c("06","07","08")] = "SU"
season[date %in% c("09","10","11")] = "F"

date2 = as.factor(season)
mydata$date= date2

dist_matrix <- vegdist(mydata[,1:9],method="bray")
result1 <- adonis2(dist_matrix ~ date + response, data = mydata)
result <- adonis2(dist_matrix ~ response, data = mydata,strata=date)

useme = mydata[mydata$response =="PnasArk"| mydata$response ==  "PphoArk",]
dist_matrix <- vegdist(useme[,1:9],method="bray")
result2 <- adonis2(dist_matrix ~ date + response, data = useme)

useme = mydata[mydata$response =="Pbru"| mydata$response ==  "PphoRed",]
dist_matrix <- vegdist(useme[,1:9],method="bray")
result3 <- adonis2(dist_matrix ~ date + response, data = useme)

useme = mydata[mydata$response =="PnasStFr"| mydata$response ==  "PphoBlack",]
dist_matrix <- vegdist(useme[,1:9],method="bray")
result4 <- adonis2(dist_matrix ~ date + response, data = useme)

useme = mydata[mydata$response =="Pnas"| mydata$response ==  "PnasWhite",]
dist_matrix <- vegdist(useme[,1:9],method="bray")
result5 <- adonis2(dist_matrix ~ date+ response, data = useme)

pvals <- c(
  result2[1:2,5], # Main effects from aov1
  result3[1:2,5], # Main effects from aov1
  result4[1:2,5], # Main effects from aov1
  result5[1:2,5] # Main effects from aov1
  
  
)

p.adjust(pvals, method = "holm")  # safer than Bonferroni

# repeat without date 

useme = mydata[mydata$response =="PnasArk"| mydata$response ==  "PphoArk",]
dist_matrix <- vegdist(useme[,1:9],method="bray")
result2 <- adonis2(dist_matrix ~ response, data = useme)

useme = mydata[mydata$response =="Pbru"| mydata$response ==  "PphoRed",]
dist_matrix <- vegdist(useme[,1:9],method="bray")
result3 <- adonis2(dist_matrix ~ response, data = useme)

useme = mydata[mydata$response =="PnasStFr"| mydata$response ==  "PphoBlack",]
dist_matrix <- vegdist(useme[,1:9],method="bray")
result4 <- adonis2(dist_matrix ~ response, data = useme)

useme = mydata[mydata$response =="Pnas"| mydata$response ==  "PnasWhite",]
dist_matrix <- vegdist(useme[,1:9],method="bray")
result5 <- adonis2(dist_matrix ~ response, data = useme)

pvals <- c(
  result2[1,5], # Main effects from aov1
  result3[1,5], # Main effects from aov1
  result4[1,5], # Main effects from aov1
  result5[1,5] # Main effects from aov1
  
  
)

p.adjust(pvals, method = "holm")  # safer than Bonferroni

